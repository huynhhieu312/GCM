<?php
/**
 * Database config variables
 */
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASSWORD", "");
define("DB_DATABASE", "gcmdemo");

/*
 * Google API Key
 */
define("GOOGLE_API_KEY", "AIzaSyD2Ki9bOc_yj6NnwpDneNiqflBffgHiGaY"); // Place your Google API Key
?>